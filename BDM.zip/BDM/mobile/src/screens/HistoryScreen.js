import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, ActivityIndicator } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useFocusEffect } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import axios from 'axios';
import API_URL from '../api/config';
import Footer from '../components/Footer';
import { COLORS } from '../constants/theme';

const HistoryScreen = ({ navigation }) => {
    const [history, setHistory] = useState([]);
    const [loading, setLoading] = useState(true);

    const calculateNextDonation = (lastDate) => {
        if (!lastDate) return null;
        const date = new Date(lastDate);
        date.setDate(date.getDate() + 90); // Standard 3-month (90 days) rule
        return date.toISOString().split('T')[0];
    };

    useFocusEffect(
        useCallback(() => {
            const loadHistory = async () => {
                setLoading(true);
                try {
                    const storedProfile = await AsyncStorage.getItem('userProfile');
                    if (storedProfile) {
                        const profile = JSON.parse(storedProfile);

                        // Fetch fresh data from API
                        const response = await axios.get(`${API_URL}/api/donors/${profile._id}`);
                        const freshDonor = response.data;

                        const lastDate = (freshDonor.lastDonationDate || freshDonor.createdAt || new Date().toISOString()).split('T')[0];
                        const nextDate = calculateNextDonation(lastDate);

                        const historyItem = {
                            id: '1',
                            date: lastDate,
                            nextDate: nextDate,
                            type: 'Blood Donation',
                            location: freshDonor.city,
                            status: 'Completed',
                            bloodGroup: freshDonor.bloodGroup
                        };
                        setHistory([historyItem]);

                        // Sync back to storage
                        await AsyncStorage.setItem('userProfile', JSON.stringify(freshDonor));
                    }
                } catch (error) {
                    console.error('History sync error:', error);
                    setLoading(false);
                } finally {
                    setLoading(false);
                }
            };
            loadHistory();
        }, [])
    );

    const renderItem = ({ item }) => {
        const today = new Date().toISOString().split('T')[0];
        const isEligible = today >= item.nextDate;

        return (
            <View style={styles.historyCard}>
                <View style={styles.cardHeader}>
                    <View style={styles.typeBadge}>
                        <MaterialCommunityIcons name="water" size={16} color={COLORS.primary} />
                        <Text style={styles.typeText}>{item.type}</Text>
                    </View>
                    <Text style={styles.dateText}>Last: {item.date}</Text>
                </View>

                <View style={styles.cardBody}>
                    <View style={styles.infoRow}>
                        <Ionicons name="location-outline" size={16} color="#888" />
                        <Text style={styles.infoText}>{item.location}</Text>
                    </View>
                    <View style={styles.infoRow}>
                        <Ionicons name="checkmark-circle-outline" size={16} color="#2BA84A" />
                        <Text style={[styles.infoText, { color: '#2BA84A' }]}>{item.status}</Text>
                    </View>

                    <View style={styles.nextDonationBox}>
                        <View style={styles.divider} />
                        <View style={styles.nextInfoRow}>
                            <View>
                                <Text style={styles.nextLabel}>Next Eligible Date</Text>
                                <Text style={styles.nextValue}>{item.nextDate}</Text>
                            </View>
                            <View style={[styles.statusTag, { backgroundColor: isEligible ? '#E8F5E9' : '#FFF3E0' }]}>
                                <Text style={[styles.statusTagText, { color: isEligible ? '#2E7D32' : '#EF6C00' }]}>
                                    {isEligible ? 'Can Donate Now' : 'Wait Period'}
                                </Text>
                            </View>
                        </View>
                    </View>
                </View>

                <View style={styles.bloodTag}>
                    <Text style={styles.bloodText}>{item.bloodGroup}</Text>
                </View>
            </View>
        );
    };

    return (
        <SafeAreaView style={styles.container}>
            <View style={styles.header}>
                <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
                    <Ionicons name="arrow-back" size={24} color="#000" />
                </TouchableOpacity>
                <Text style={styles.headerTitle}>Donation History</Text>
            </View>

            <View style={styles.content}>
                {loading ? (
                    <ActivityIndicator size="large" color={COLORS.primary} style={{ marginTop: 50 }} />
                ) : (
                    <>
                        <View style={styles.infoBanner}>
                            <Ionicons name="information-circle-outline" size={20} color={COLORS.primary} />
                            <Text style={styles.infoBannerText}>
                                Standard interval between blood donations is 3 months (90 days).
                            </Text>
                        </View>

                        {history.length > 0 ? (
                            <FlatList
                                data={history}
                                renderItem={renderItem}
                                keyExtractor={item => item.id}
                                contentContainerStyle={styles.list}
                                showsVerticalScrollIndicator={false}
                                ListFooterComponent={<Footer />}
                            />
                        ) : (
                            <View style={styles.emptyContainer}>
                                <View style={styles.emptyIcon}>
                                    <MaterialCommunityIcons name="history" size={60} color={COLORS.primary} />
                                </View>
                                <Text style={styles.emptyTitle}>No History found</Text>
                                <Text style={styles.emptySubtitle}>You haven't recorded any donations yet.</Text>
                            </View>
                        )}
                    </>
                )}
            </View>
        </SafeAreaView>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
    },
    header: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingHorizontal: 20,
        paddingVertical: 15,
        borderBottomWidth: 1,
        borderBottomColor: '#f5f5f5',
    },
    backBtn: {
        marginRight: 15,
    },
    headerTitle: {
        fontSize: 20,
        fontWeight: 'bold',
        color: '#1a1a1a',
    },
    content: {
        flex: 1,
        padding: 20,
    },
    infoBanner: {
        flexDirection: 'row',
        backgroundColor: COLORS.primaryTint,
        padding: 12,
        borderRadius: 12,
        alignItems: 'center',
        gap: 10,
        marginBottom: 20,
    },
    infoBannerText: {
        flex: 1,
        fontSize: 12,
        color: COLORS.primary,
        fontWeight: '600',
    },
    list: {
        paddingBottom: 20,
    },
    historyCard: {
        backgroundColor: '#fff',
        borderRadius: 20,
        padding: 20,
        marginBottom: 15,
        borderWidth: 1,
        borderColor: '#f0f0f0',
        elevation: 3,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.05,
        shadowRadius: 10,
    },
    cardHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 15,
    },
    typeBadge: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: COLORS.primaryTint,
        paddingHorizontal: 10,
        paddingVertical: 5,
        borderRadius: 8,
        gap: 5,
    },
    typeText: {
        fontSize: 12,
        fontWeight: 'bold',
        color: COLORS.primary,
    },
    dateText: {
        fontSize: 12,
        color: '#999',
        fontWeight: '600',
    },
    cardBody: {
        gap: 8,
    },
    infoRow: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 8,
    },
    infoText: {
        fontSize: 14,
        color: '#666',
        fontWeight: '500',
    },
    nextDonationBox: {
        marginTop: 10,
    },
    divider: {
        height: 1,
        backgroundColor: '#f5f5f5',
        marginVertical: 12,
    },
    nextInfoRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
    },
    nextLabel: {
        fontSize: 12,
        color: '#999',
        fontWeight: '600',
        marginBottom: 2,
    },
    nextValue: {
        fontSize: 15,
        fontWeight: 'bold',
        color: '#333',
    },
    statusTag: {
        paddingHorizontal: 10,
        paddingVertical: 4,
        borderRadius: 6,
    },
    statusTagText: {
        fontSize: 11,
        fontWeight: 'bold',
    },
    bloodTag: {
        position: 'absolute',
        top: 60,
        right: 20,
        backgroundColor: COLORS.primary,
        paddingHorizontal: 10,
        paddingVertical: 4,
        borderRadius: 8,
    },
    bloodText: {
        color: '#fff',
        fontWeight: 'bold',
        fontSize: 12,
    },
    emptyContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        paddingHorizontal: 40,
    },
    emptyIcon: {
        width: 100,
        height: 100,
        borderRadius: 50,
        backgroundColor: COLORS.primaryTint,
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: 20,
    },
    emptyTitle: {
        fontSize: 20,
        fontWeight: 'bold',
        color: '#1a1a1a',
        marginBottom: 10,
    },
    emptySubtitle: {
        fontSize: 14,
        color: '#888',
        textAlign: 'center',
        lineHeight: 20,
    }
});

export default HistoryScreen;
