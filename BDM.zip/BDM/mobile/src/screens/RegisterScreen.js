import React, { useState } from 'react';
import { View, StyleSheet, ScrollView, Alert, Text, TouchableOpacity, KeyboardAvoidingView, Platform } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import DateTimePicker from '@react-native-community/datetimepicker';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';
import Input from '../components/Input';
import Button from '../components/Button';
import SuccessModal from '../components/SuccessModal';
import API_URL from '../api/config';
import { COLORS } from '../constants/theme';

const RegisterScreen = ({ navigation }) => {
    const [loading, setLoading] = useState(false);
    const [showDatePicker, setShowDatePicker] = useState(false);
    const [showSuccess, setShowSuccess] = useState(false);

    const [formData, setFormData] = useState({
        fullName: '',
        age: '',
        gender: 'Male',
        bloodGroup: '',
        phone: '',
        city: '',
        lastDonationDate: '',
        medicalNotes: ''
    });

    const bloodGroups = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

    const handleChange = (name, value) => {
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleDateChange = (event, selectedDate) => {
        setShowDatePicker(false);
        if (selectedDate) {
            const formattedDate = selectedDate.toISOString().split('T')[0];
            handleChange('lastDonationDate', formattedDate);
        }
    };

    const handleSubmit = async () => {
        const { fullName, age, gender, bloodGroup, phone, city } = formData;

        // 1. Check for empty fields
        if (!fullName.trim() || !age.trim() || !gender || !bloodGroup || !phone.trim() || !city.trim()) {
            Alert.alert('Validation Error', 'Please fill in all required fields.');
            return;
        }

        // 2. Validate Full Name
        if (fullName.trim().length < 3) {
            Alert.alert('Validation Error', 'Full name must be at least 3 characters long.');
            return;
        }

        // 3. Validate Phone Number (11 digits)
        const phoneRegex = /^[0-9]{11}$/;
        if (!phoneRegex.test(phone.trim())) {
            Alert.alert('Validation Error', 'Phone number must be exactly 11 digits.');
            return;
        }

        // 4. Validate Age (18-65)
        const ageNum = parseInt(age);
        if (isNaN(ageNum) || ageNum < 18 || ageNum > 65) {
            Alert.alert('Validation Error', 'Donor age must be between 18 and 65.');
            return;
        }

        setLoading(true);
        try {
            const response = await axios.post(`${API_URL}/api/donors`, formData);

            // Save to AsyncStorage for Profile Section
            await AsyncStorage.setItem('userProfile', JSON.stringify(response.data));

            setShowSuccess(true);

            // Reset Form
            setFormData({
                fullName: '',
                age: '',
                gender: 'Male',
                bloodGroup: '',
                phone: '',
                city: '',
                lastDonationDate: '',
                medicalNotes: ''
            });
        } catch (error) {
            console.error(error);
            Alert.alert('Error', 'Failed to register. Please try again.');
        } finally {
            setLoading(false);
        }
    };

    return (
        <SafeAreaView style={styles.container}>
            <View style={styles.header}>
                <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
                    <Ionicons name="arrow-back" size={24} color="#000" />
                </TouchableOpacity>
                <Text style={styles.headerTitle}>Become a Donor</Text>
            </View>

            <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>

                <View style={styles.inputContainer}>
                    <View style={styles.inputWrapper}>
                        <Ionicons name="person-outline" size={20} color="#888" style={styles.icon} />
                        <Input
                            placeholder="Full Name"
                            value={formData.fullName}
                            onChangeText={(t) => handleChange('fullName', t)}
                            containerStyle={styles.innerInput}
                        />
                    </View>
                </View>

                <View style={styles.inputContainer}>
                    <View style={styles.inputWrapper}>
                        <MaterialCommunityIcons name="account-outline" size={20} color="#888" style={styles.icon} />
                        <Input
                            placeholder="Age"
                            value={formData.age}
                            onChangeText={(t) => handleChange('age', t)}
                            keyboardType="numeric"
                            containerStyle={styles.innerInput}
                        />
                    </View>
                </View>

                <View style={styles.genderRow}>
                    <TouchableOpacity
                        style={[styles.genderBtn, formData.gender === 'Male' && styles.genderBtnActive]}
                        onPress={() => handleChange('gender', 'Male')}
                    >
                        <Ionicons name="man" size={18} color={formData.gender === 'Male' ? '#fff' : '#888'} />
                        <Text style={[styles.genderBtnText, formData.gender === 'Male' && styles.genderBtnTextActive]}>Male</Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                        style={[styles.genderBtn, formData.gender === 'Female' && styles.genderBtnActive]}
                        onPress={() => handleChange('gender', 'Female')}
                    >
                        <Ionicons name="woman" size={18} color={formData.gender === 'Female' ? '#fff' : '#888'} />
                        <Text style={[styles.genderBtnText, formData.gender === 'Female' && styles.genderBtnTextActive]}>Female</Text>
                    </TouchableOpacity>
                </View>

                <View style={styles.bloodSection}>
                    <View style={styles.sectionHeader}>
                        <Text style={styles.sectionTitle}>Blood Group</Text>
                        <Ionicons name="chevron-down" size={20} color="#888" />
                    </View>

                    <View style={styles.bloodGroupContainer}>
                        <View style={styles.popularRow}>
                            <Ionicons name="water" size={18} color={COLORS.primary} />
                            <Text style={styles.popularText}>Popular</Text>
                            <Ionicons name="chevron-down" size={16} color="#ccc" style={{ marginLeft: 'auto' }} />
                        </View>

                        <View style={styles.bloodGrid}>
                            {bloodGroups.map((bg) => (
                                <TouchableOpacity
                                    key={bg}
                                    style={styles.bloodItem}
                                    onPress={() => handleChange('bloodGroup', bg)}
                                >
                                    <View style={styles.checkbox}>
                                        {formData.bloodGroup === bg && <View style={styles.checked} />}
                                    </View>
                                    <Text style={styles.bloodText}>{bg}</Text>
                                </TouchableOpacity>
                            ))}
                        </View>
                    </View>
                </View>

                <View style={styles.inputContainer}>
                    <View style={styles.inputWrapper}>
                        <Ionicons name="call-outline" size={20} color="#888" style={styles.icon} />
                        <Input
                            placeholder="Phone Number"
                            value={formData.phone}
                            onChangeText={(t) => handleChange('phone', t)}
                            keyboardType="phone-pad"
                            containerStyle={styles.innerInput}
                        />
                    </View>
                </View>

                <View style={styles.inputContainer}>
                    <View style={styles.inputWrapper}>
                        <Ionicons name="location-outline" size={20} color="#888" style={styles.icon} />
                        <Input
                            placeholder="City"
                            value={formData.city}
                            onChangeText={(t) => handleChange('city', t)}
                            containerStyle={styles.innerInput}
                        />
                    </View>
                </View>

                <View style={styles.inputContainer}>
                    <TouchableOpacity
                        style={styles.inputWrapper}
                        onPress={() => setShowDatePicker(true)}
                        activeOpacity={0.7}
                    >
                        <Input
                            placeholder="Last Donation Date"
                            value={formData.lastDonationDate}
                            containerStyle={styles.innerInput}
                            editable={false}
                        />
                        <Ionicons name="calendar-outline" size={20} color="#888" style={styles.iconRight} />
                    </TouchableOpacity>
                </View>

                {showDatePicker && (
                    <DateTimePicker
                        value={formData.lastDonationDate ? new Date(formData.lastDonationDate) : new Date()}
                        mode="date"
                        display="default"
                        onChange={handleDateChange}
                        maximumDate={new Date()}
                    />
                )}

                <TouchableOpacity style={styles.submitBtn} onPress={handleSubmit} disabled={loading}>
                    <Text style={styles.submitBtnText}>Submit</Text>
                </TouchableOpacity>

                <Text style={styles.footerText}>Your data is kept secure and private.</Text>
            </ScrollView>

            <SuccessModal
                isVisible={showSuccess}
                onClose={() => {
                    setShowSuccess(false);
                    navigation.navigate('HomeTab');
                }}
                message="Your registration as a blood donor was successful. Thank you for your contribution!"
            />
        </SafeAreaView>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
    },
    header: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingHorizontal: 20,
        paddingVertical: 15,
    },
    backBtn: {
        marginRight: 15,
    },
    headerTitle: {
        fontSize: 20,
        fontWeight: '700',
    },
    content: {
        padding: 20,
        paddingBottom: 100,
    },
    inputContainer: {
        marginBottom: 16,
    },
    inputWrapper: {
        flexDirection: 'row',
        alignItems: 'center',
        borderWidth: 1,
        borderColor: '#eee',
        borderRadius: 12,
        paddingHorizontal: 15,
        backgroundColor: '#fdfdfd',
        height: 55,
    },
    icon: {
        marginRight: 10,
    },
    iconRight: {
        marginLeft: 'auto',
    },
    innerInput: {
        flex: 1,
        marginBottom: 0,
        borderWidth: 0,
        backgroundColor: 'transparent',
        padding: 0,
    },
    genderRow: {
        flexDirection: 'row',
        gap: 12,
        marginBottom: 20,
    },
    genderBtn: {
        flex: 1,
        height: 50,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 12,
        backgroundColor: '#f5f5f5',
        gap: 8,
    },
    genderBtnActive: {
        backgroundColor: COLORS.primary,
    },
    genderBtnText: {
        fontSize: 15,
        fontWeight: '600',
        color: '#888',
    },
    genderBtnTextActive: {
        color: '#fff',
    },
    bloodSection: {
        borderWidth: 1,
        borderColor: '#eee',
        borderRadius: 15,
        padding: 15,
        marginBottom: 20,
    },
    sectionHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 15,
    },
    sectionTitle: {
        fontSize: 16,
        fontWeight: 'bold',
        color: '#444',
    },
    bloodGroupContainer: {
        backgroundColor: '#fafafa',
        borderRadius: 12,
        padding: 12,
    },
    popularRow: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 15,
        gap: 8,
    },
    popularText: {
        fontSize: 14,
        fontWeight: 'bold',
        color: '#444',
    },
    bloodGrid: {
        flexDirection: 'row',
        flexWrap: 'wrap',
    },
    bloodItem: {
        width: '50%',
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 12,
        gap: 10,
    },
    checkbox: {
        width: 18,
        height: 18,
        borderRadius: 9,
        borderWidth: 2,
        borderColor: COLORS.primary,
        justifyContent: 'center',
        alignItems: 'center',
    },
    checked: {
        width: 8,
        height: 8,
        borderRadius: 4,
        backgroundColor: COLORS.primary,
    },
    bloodText: {
        fontSize: 14,
        fontWeight: '600',
        color: '#444',
    },
    submitBtn: {
        backgroundColor: COLORS.primary,
        height: 60,
        borderRadius: 15,
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 10,
    },
    submitBtnText: {
        color: '#fff',
        fontSize: 18,
        fontWeight: 'bold',
    },
    footerText: {
        textAlign: 'center',
        marginTop: 15,
        color: '#888',
        fontSize: 13,
    }
});

export default RegisterScreen;
