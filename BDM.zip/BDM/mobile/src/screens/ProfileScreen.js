import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Image, ActivityIndicator } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useFocusEffect } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Ionicons, Feather } from '@expo/vector-icons';
import axios from 'axios';
import API_URL from '../api/config';
import Footer from '../components/Footer';
import { COLORS } from '../constants/theme';

const ProfileScreen = ({ navigation }) => {
    const [userProfile, setUserProfile] = useState(null);
    const [loading, setLoading] = useState(true);

    const calculateNextDonation = (lastDate) => {
        if (!lastDate) return null;
        const date = new Date(lastDate);
        date.setDate(date.getDate() + 90);
        return date.toISOString().split('T')[0];
    };

    useFocusEffect(
        useCallback(() => {
            const loadProfile = async () => {
                setLoading(true);
                try {
                    const storedProfile = await AsyncStorage.getItem('userProfile');
                    if (storedProfile) {
                        const profile = JSON.parse(storedProfile);

                        // Fetch fresh data from API
                        const response = await axios.get(`${API_URL}/api/donors/${profile._id}`);
                        const freshProfile = response.data;

                        const nextDate = calculateNextDonation(freshProfile.lastDonationDate || freshProfile.createdAt);
                        setUserProfile({ ...freshProfile, nextDonationDate: nextDate });

                        // Sync back to storage
                        await AsyncStorage.setItem('userProfile', JSON.stringify(freshProfile));
                    }
                } catch (error) {
                    console.error('Profile sync error:', error);
                    // Fallback to stored profile if API fails
                    const storedProfile = await AsyncStorage.getItem('userProfile');
                    if (storedProfile) {
                        const profile = JSON.parse(storedProfile);
                        const nextDate = calculateNextDonation(profile.lastDonationDate || profile.createdAt);
                        setUserProfile({ ...profile, nextDonationDate: nextDate });
                    }
                } finally {
                    setLoading(false);
                }
            };
            loadProfile();
        }, [])
    );

    const handleLogout = async () => {
        await AsyncStorage.removeItem('userProfile');
        setUserProfile(null);
    };

    if (loading) {
        return (
            <SafeAreaView style={styles.container}>
                <View style={[styles.emptyContainer, { justifyContent: 'center' }]}>
                    <ActivityIndicator size="large" color={COLORS.primary} />
                </View>
            </SafeAreaView>
        );
    }

    if (!userProfile) {
        return (
            <SafeAreaView style={styles.container}>
                <View style={styles.header}>
                    <Text style={styles.headerTitle}>My Profile</Text>
                </View>
                <View style={styles.emptyContainer}>
                    <View style={styles.emptyIconContainer}>
                        <Feather name="user" size={60} color={COLORS.primary} />
                    </View>
                    <Text style={styles.emptyTitle}>No Profile Found</Text>
                    <Text style={styles.emptySubtitle}>Register as a donor to see your profile details here.</Text>
                    <TouchableOpacity
                        style={styles.registerBtn}
                        onPress={() => navigation.navigate('AddDonor')}
                    >
                        <Text style={styles.registerBtnText}>Become a Donor</Text>
                    </TouchableOpacity>
                </View>
            </SafeAreaView>
        );
    }

    const today = new Date().toISOString().split('T')[0];
    const isEligible = today >= userProfile.nextDonationDate;

    return (
        <SafeAreaView style={styles.container}>
            <View style={styles.header}>
                <Text style={styles.headerTitle}>My Profile</Text>
                <TouchableOpacity onPress={handleLogout}>
                    <Ionicons name="log-out-outline" size={24} color={COLORS.primary} />
                </TouchableOpacity>
            </View>

            <ScrollView contentContainerStyle={styles.content}>
                <View style={styles.profileCard}>
                    <View style={styles.avatarLarge}>
                        <Text style={styles.avatarTextLarge}>{userProfile.fullName.charAt(0).toUpperCase()}</Text>
                    </View>
                    <Text style={styles.donorName}>{userProfile.fullName}</Text>
                    <View style={styles.bloodBadgeLarge}>
                        <Text style={styles.bloodTextLarge}>{userProfile.bloodGroup}</Text>
                    </View>
                </View>

                <View style={styles.eligibilityBanner}>
                    <View style={[styles.statusIndicator, { backgroundColor: isEligible ? '#4CAF50' : '#FF9800' }]} />
                    <View>
                        <Text style={styles.eligibilityTitle}>
                            {isEligible ? 'Can Donate Now' : 'In Wait Period'}
                        </Text>
                        <Text style={styles.eligibilitySubtitle}>
                            {isEligible
                                ? 'You can donate blood today! ❤️'
                                : `Next eligible: ${userProfile.nextDonationDate}`}
                        </Text>
                    </View>
                </View>

                <View style={styles.infoCard}>
                    <Text style={styles.sectionTitle}>Details</Text>

                    <View style={styles.infoRow}>
                        <View style={styles.iconBox}>
                            <Ionicons name="person-outline" size={20} color={COLORS.primary} />
                        </View>
                        <View>
                            <Text style={styles.infoLabel}>Age & Gender</Text>
                            <Text style={styles.infoValue}>{userProfile.age} yrs • {userProfile.gender}</Text>
                        </View>
                    </View>

                    <View style={styles.infoRow}>
                        <View style={styles.iconBox}>
                            <Ionicons name="call-outline" size={20} color={COLORS.primary} />
                        </View>
                        <View>
                            <Text style={styles.infoLabel}>Contact</Text>
                            <Text style={styles.infoValue}>{userProfile.phone}</Text>
                        </View>
                    </View>

                    <View style={styles.infoRow}>
                        <View style={styles.iconBox}>
                            <Ionicons name="location-outline" size={20} color={COLORS.primary} />
                        </View>
                        <View>
                            <Text style={styles.infoLabel}>Location</Text>
                            <Text style={styles.infoValue}>{userProfile.city}</Text>
                        </View>
                    </View>

                    <View style={styles.infoRow}>
                        <View style={styles.iconBox}>
                            <Ionicons name="calendar-outline" size={20} color={COLORS.primary} />
                        </View>
                        <View>
                            <Text style={styles.infoLabel}>Last Donation</Text>
                            <Text style={styles.infoValue}>{(userProfile.lastDonationDate || 'Not yet donated').split('T')[0]}</Text>
                        </View>
                    </View>

                    <View style={[styles.infoRow, { marginBottom: 0 }]}>
                        <View style={styles.iconBox}>
                            <Ionicons name="alarm-outline" size={20} color={COLORS.primary} />
                        </View>
                        <View>
                            <Text style={styles.infoLabel}>Next Eligible Date</Text>
                            <Text style={styles.infoValue}>{userProfile.nextDonationDate}</Text>
                        </View>
                    </View>
                </View>

                {userProfile.medicalNotes && (
                    <View style={styles.infoCard}>
                        <Text style={styles.sectionTitle}>Medical Notes</Text>
                        <Text style={styles.notesText}>{userProfile.medicalNotes}</Text>
                    </View>
                )}

                <View style={styles.footer}>
                    <Text style={styles.footerText}>Thank you for being a lifesaver! ❤️</Text>

                    <TouchableOpacity
                        style={styles.adminAccessBtn}
                        onPress={() => navigation.navigate('AdminLogin')}
                    >
                        <Ionicons name="shield-checkmark-outline" size={16} color="#bbb" />
                        <Text style={styles.adminAccessText}>Admin Portal</Text>
                    </TouchableOpacity>
                </View>
                <Footer />
            </ScrollView>
        </SafeAreaView>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
    },
    header: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingHorizontal: 25,
        paddingVertical: 15,
        borderBottomWidth: 1,
        borderBottomColor: '#f5f5f5',
    },
    headerTitle: {
        fontSize: 22,
        fontWeight: 'bold',
        color: '#1a1a1a',
    },
    content: {
        padding: 20,
        paddingBottom: 100,
    },
    profileCard: {
        alignItems: 'center',
        marginBottom: 20,
        marginTop: 10,
    },
    avatarLarge: {
        width: 100,
        height: 100,
        borderRadius: 50,
        backgroundColor: COLORS.primaryTint,
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: 15,
        borderWidth: 2,
        borderColor: COLORS.primary,
    },
    avatarTextLarge: {
        fontSize: 40,
        fontWeight: 'bold',
        color: COLORS.primary,
    },
    donorName: {
        fontSize: 24,
        fontWeight: 'bold',
        color: '#1a1a1a',
        marginBottom: 8,
    },
    bloodBadgeLarge: {
        backgroundColor: COLORS.primary,
        paddingHorizontal: 20,
        paddingVertical: 8,
        borderRadius: 15,
    },
    bloodTextLarge: {
        color: '#fff',
        fontSize: 18,
        fontWeight: 'bold',
    },
    eligibilityBanner: {
        flexDirection: 'row',
        backgroundColor: '#fdfdfd',
        padding: 15,
        borderRadius: 15,
        alignItems: 'center',
        marginBottom: 20,
        borderWidth: 1,
        borderColor: '#f0f0f0',
        gap: 15,
    },
    statusIndicator: {
        width: 12,
        height: 12,
        borderRadius: 6,
    },
    eligibilityTitle: {
        fontSize: 15,
        fontWeight: 'bold',
        color: '#333',
    },
    eligibilitySubtitle: {
        fontSize: 12,
        color: '#666',
        marginTop: 2,
    },
    infoCard: {
        backgroundColor: '#fff',
        borderRadius: 20,
        padding: 20,
        marginBottom: 20,
        borderWidth: 1,
        borderColor: '#f0f0f0',
        elevation: 2,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.05,
        shadowRadius: 10,
    },
    sectionTitle: {
        fontSize: 16,
        fontWeight: 'bold',
        color: COLORS.primary,
        marginBottom: 20,
        textTransform: 'uppercase',
    },
    infoRow: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 20,
    },
    iconBox: {
        width: 40,
        height: 40,
        borderRadius: 12,
        backgroundColor: COLORS.primaryTint,
        justifyContent: 'center',
        alignItems: 'center',
        marginRight: 15,
    },
    infoLabel: {
        fontSize: 12,
        color: '#999',
        fontWeight: '600',
    },
    infoValue: {
        fontSize: 16,
        fontWeight: '700',
        color: '#333',
    },
    notesText: {
        fontSize: 14,
        color: '#666',
        lineHeight: 22,
        fontStyle: 'italic',
    },
    emptyContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        paddingHorizontal: 40,
    },
    emptyIconContainer: {
        width: 120,
        height: 120,
        borderRadius: 60,
        backgroundColor: COLORS.primaryTint,
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: 20,
    },
    emptyTitle: {
        fontSize: 20,
        fontWeight: 'bold',
        color: '#1a1a1a',
        marginBottom: 10,
    },
    emptySubtitle: {
        fontSize: 14,
        color: '#888',
        textAlign: 'center',
        marginBottom: 30,
        lineHeight: 20,
    },
    registerBtn: {
        backgroundColor: COLORS.primary,
        paddingHorizontal: 30,
        paddingVertical: 14,
        borderRadius: 15,
    },
    registerBtnText: {
        color: '#fff',
        fontSize: 16,
        fontWeight: 'bold',
    },
    footer: {
        alignItems: 'center',
        marginTop: 30,
        marginBottom: 30,
    },
    footerText: {
        fontSize: 14,
        color: '#bbb',
        fontWeight: '500',
        marginBottom: 15,
    },
    adminAccessBtn: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 6,
        padding: 10,
    },
    adminAccessText: {
        fontSize: 12,
        color: '#bbb',
        fontWeight: 'bold',
    }
});

export default ProfileScreen;
