import React, { useEffect, useRef } from 'react';
import { View, Text, StyleSheet, Animated, StatusBar } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { COLORS } from '../constants/theme';

const SplashScreen = ({ onFinish }) => {
    const fadeAnim = useRef(new Animated.Value(0)).current;
    const scaleAnim = useRef(new Animated.Value(0.9)).current;

    useEffect(() => {
        Animated.parallel([
            Animated.timing(fadeAnim, {
                toValue: 1,
                duration: 1000,
                useNativeDriver: true,
            }),
            Animated.timing(scaleAnim, {
                toValue: 1,
                duration: 1000,
                useNativeDriver: true,
            })
        ]).start();

        const timer = setTimeout(() => {
            onFinish();
        }, 3000);

        return () => clearTimeout(timer);
    }, []);

    return (
        <View style={styles.container}>
            <StatusBar barStyle="dark-content" backgroundColor="#ffffff" />
            <Animated.View style={[styles.content, { opacity: fadeAnim, transform: [{ scale: scaleAnim }] }]}>
                <View style={styles.iconContainer}>
                    <Ionicons name="heart" size={100} color={COLORS.primary} />
                    <View style={styles.dropContainer}>
                        <Ionicons name="water" size={40} color={COLORS.primary} />
                    </View>
                </View>
                <Text style={styles.title}>Savelives</Text>
                <View style={styles.line} />
                <Text style={styles.tagline}>Donate Blood. Save Lives.</Text>
            </Animated.View>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#ffffff',
        justifyContent: 'center',
        alignItems: 'center',
    },
    content: {
        alignItems: 'center',
    },
    iconContainer: {
        position: 'relative',
        marginBottom: 20,
    },
    dropContainer: {
        position: 'absolute',
        bottom: 5,
        right: -10,
        backgroundColor: '#fff',
        borderRadius: 20,
        padding: 2,
    },
    title: {
        fontSize: 42,
        fontWeight: '900',
        color: COLORS.primary,
        letterSpacing: -1,
    },
    line: {
        width: 40,
        height: 4,
        backgroundColor: COLORS.primary,
        borderRadius: 2,
        marginVertical: 15,
    },
    tagline: {
        fontSize: 16,
        color: COLORS.text,
        fontWeight: '500',
        letterSpacing: 1,
    },
});

export default SplashScreen;
