import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Dimensions, StatusBar, Image } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { COLORS } from '../constants/theme';

const { width } = Dimensions.get('window');

const HomeScreen = ({ navigation }) => {

    const ActionCard = ({ title, subtitle, icon, isPrimary, onPress }) => (
        <TouchableOpacity
            style={[styles.card, isPrimary ? styles.primaryCard : styles.secondaryCard]}
            onPress={onPress}
            activeOpacity={0.8}
        >
            <View style={styles.cardContent}>
                <View style={styles.cardTextContainer}>
                    <Text style={[styles.cardTitle, { color: isPrimary ? '#fff' : '#1a1a1a' }]}>{title}</Text>
                    <Text style={[styles.cardSubtitle, { color: isPrimary ? 'rgba(255,255,255,0.8)' : '#666' }]}>{subtitle}</Text>
                </View>
                <View style={[styles.cardIconContainer, { backgroundColor: isPrimary ? 'rgba(255,255,255,0.2)' : COLORS.primaryTint }]}>
                    <MaterialCommunityIcons name={icon} size={32} color={isPrimary ? '#fff' : COLORS.primary} />
                </View>
            </View>
            <View style={styles.cardArrow}>
                <Ionicons name="chevron-forward" size={16} color={isPrimary ? '#fff' : '#ccc'} />
            </View>
        </TouchableOpacity>
    );

    return (
        <View style={styles.container}>
            <StatusBar barStyle="dark-content" backgroundColor="transparent" translucent />

            {/* Soft red shapes in background */}
            <View style={styles.bgDecorationContainer}>
                <View style={[styles.bgCircle, { top: -50, left: -50, width: 200, height: 200 }]} />
                <View style={[styles.bgCircle, { top: 100, right: -100, width: 300, height: 300, opacity: 0.05 }]} />
            </View>

            <SafeAreaView style={styles.safeArea}>
                <View style={styles.header}>
                    <Text style={styles.welcomeText}>Welcome to</Text>
                    <Text style={styles.brandName}>Savelives</Text>
                    <Text style={styles.headerSubtitle}>Every donation counts.</Text>
                </View>

                <ScrollView
                    showsVerticalScrollIndicator={false}
                    contentContainerStyle={styles.scrollContent}
                >
                    <ActionCard
                        title="Become a Donor"
                        subtitle="Register and save lives"
                        icon="water-plus"
                        isPrimary
                        onPress={() => navigation.navigate('AddDonor')}
                    />

                    <ActionCard
                        title="Find Donors"
                        subtitle="Search by blood group or city."
                        icon="card-search-outline"
                        onPress={() => navigation.navigate('DonorListTab')}
                    />

                    <ActionCard
                        title="Donation History"
                        subtitle="View your donation records"
                        icon="history"
                        onPress={() => navigation.navigate('DonationHistory')}
                    />

                    <ActionCard
                        title="Your Profile"
                        subtitle="Manage your details"
                        icon="account-outline"
                        onPress={() => navigation.navigate('ProfileTab')}
                    />
                </ScrollView>
            </SafeAreaView>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
    },
    bgDecorationContainer: {
        ...StyleSheet.absoluteFillObject,
        overflow: 'hidden',
    },
    bgCircle: {
        position: 'absolute',
        borderRadius: 150,
        backgroundColor: COLORS.primary,
        opacity: 0.03,
    },
    safeArea: {
        flex: 1,
    },
    header: {
        alignItems: 'center',
        marginTop: 40,
        marginBottom: 30,
    },
    welcomeText: {
        fontSize: 18,
        fontWeight: '500',
        color: '#444',
    },
    brandName: {
        fontSize: 32,
        fontWeight: '800',
        color: COLORS.primary,
        marginVertical: 4,
    },
    headerSubtitle: {
        fontSize: 14,
        color: '#888',
        fontWeight: '500',
    },
    scrollContent: {
        paddingHorizontal: 20,
        paddingBottom: 110,
    },
    card: {
        borderRadius: 20,
        padding: 24,
        marginBottom: 16,
        flexDirection: 'row',
        alignItems: 'center',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.06,
        shadowRadius: 10,
        elevation: 3,
    },
    primaryCard: {
        backgroundColor: COLORS.primary,
    },
    secondaryCard: {
        backgroundColor: '#fff',
        borderWidth: 1,
        borderColor: '#f0f0f0',
    },
    cardContent: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
    },
    cardTextContainer: {
        flex: 1,
    },
    cardTitle: {
        fontSize: 18,
        fontWeight: 'bold',
        marginBottom: 4,
    },
    cardSubtitle: {
        fontSize: 13,
        maxWidth: '85%',
    },
    cardIconContainer: {
        width: 60,
        height: 60,
        borderRadius: 30,
        justifyContent: 'center',
        alignItems: 'center',
    },
    cardArrow: {
        position: 'absolute',
        right: 15,
        top: '50%',
        marginTop: -8,
        opacity: 0.5,
    }
});

export default HomeScreen;
