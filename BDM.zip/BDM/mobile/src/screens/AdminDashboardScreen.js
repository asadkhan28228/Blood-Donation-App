import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, Alert, ActivityIndicator } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useFocusEffect } from '@react-navigation/native';
import { Ionicons, Feather, MaterialCommunityIcons } from '@expo/vector-icons';
import axios from 'axios';
import SuccessModal from '../components/SuccessModal';
import Footer from '../components/Footer';
import API_URL from '../api/config';
import { COLORS } from '../constants/theme';

const AdminDashboardScreen = ({ navigation }) => {
    const [donors, setDonors] = useState([]);
    const [loading, setLoading] = useState(true);
    const [showSuccess, setShowSuccess] = useState(false);

    const calculateEligibility = (lastDate, createdAt) => {
        const dateStr = lastDate || createdAt;
        if (!dateStr) return { eligible: true, nextDate: '' };

        const last = new Date(dateStr.split('T')[0]);
        const next = new Date(last);
        next.setDate(next.getDate() + 90);

        const today = new Date();
        today.setHours(0, 0, 0, 0);

        return {
            eligible: today >= next,
            nextDate: next.toISOString().split('T')[0]
        };
    };

    const fetchDonors = async () => {
        setLoading(true);
        try {
            const response = await axios.get(`${API_URL}/api/donors`);
            setDonors(response.data);
        } catch (error) {
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    useFocusEffect(
        useCallback(() => {
            fetchDonors();
        }, [])
    );

    const handleDelete = (id, name) => {
        Alert.alert(
            'Delete Donor',
            `Are you sure you want to remove ${name} from the database?`,
            [
                { text: 'Cancel', style: 'cancel' },
                {
                    text: 'Delete',
                    style: 'destructive',
                    onPress: async () => {
                        try {
                            await axios.delete(`${API_URL}/api/donors/${id}`);
                            fetchDonors();
                            setShowSuccess(true);
                        } catch (error) {
                            Alert.alert('Error', 'Failed to delete donor');
                        }
                    }
                }
            ]
        );
    };

    const renderItem = ({ item }) => {
        const { eligible, nextDate } = calculateEligibility(item.lastDonationDate, item.createdAt);

        return (
            <View style={styles.card}>
                <View style={styles.cardInfo}>
                    <View style={styles.avatar}>
                        <Text style={styles.avatarText}>{item.fullName.charAt(0).toUpperCase()}</Text>
                    </View>
                    <View style={styles.details}>
                        <Text style={styles.name}>{item.fullName}</Text>
                        <Text style={styles.meta}>{item.bloodGroup} • {item.city}</Text>
                        <View style={styles.statusRow}>
                            <MaterialCommunityIcons
                                name={eligible ? "check-circle" : "clock-outline"}
                                size={12}
                                color={eligible ? "#4CAF50" : "#FF9800"}
                            />
                            <Text style={[styles.statusText, { color: eligible ? "#4CAF50" : "#FF9800" }]}>
                                {eligible ? 'Can Donate Now' : `Elegible on: ${nextDate}`}
                            </Text>
                        </View>
                    </View>
                </View>

                <View style={styles.actions}>
                    <TouchableOpacity
                        style={[styles.actionBtn, styles.editBtn]}
                        onPress={() => navigation.navigate('EditDonor', { donor: item })}
                    >
                        <Feather name="edit-2" size={18} color="#2196F3" />
                    </TouchableOpacity>
                    <TouchableOpacity
                        style={[styles.actionBtn, styles.deleteBtn]}
                        onPress={() => handleDelete(item._id, item.fullName)}
                    >
                        <Feather name="trash-2" size={18} color={COLORS.primary} />
                    </TouchableOpacity>
                </View>
            </View>
        );
    };

    return (
        <SafeAreaView style={styles.container}>
            <View style={styles.header}>
                <TouchableOpacity onPress={() => navigation.goBack()}>
                    <Ionicons name="arrow-back" size={24} color="#000" />
                </TouchableOpacity>
                <Text style={styles.headerTitle}>Admin Dashboard</Text>
                <TouchableOpacity onPress={fetchDonors}>
                    <Ionicons name="refresh" size={24} color={COLORS.primary} />
                </TouchableOpacity>
            </View>

            <View style={styles.statBar}>
                <View style={styles.statItem}>
                    <Text style={styles.statVal}>{donors.length}</Text>
                    <Text style={styles.statLabel}>Total Donors</Text>
                </View>
            </View>

            <View style={styles.content}>
                {loading ? (
                    <ActivityIndicator size="large" color={COLORS.primary} style={{ marginTop: 50 }} />
                ) : (
                    <FlatList
                        data={donors}
                        renderItem={renderItem}
                        keyExtractor={item => item._id}
                        contentContainerStyle={styles.list}
                        showsVerticalScrollIndicator={false}
                        ListFooterComponent={<Footer />}
                    />
                )}
            </View>

            <SuccessModal
                isVisible={showSuccess}
                onClose={() => setShowSuccess(false)}
                message="Donor has been permanently removed from the system."
            />
        </SafeAreaView>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
    },
    header: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingHorizontal: 20,
        paddingVertical: 15,
        borderBottomWidth: 1,
        borderBottomColor: '#f5f5f5',
    },
    headerTitle: {
        fontSize: 20,
        fontWeight: 'bold',
    },
    statBar: {
        padding: 20,
        backgroundColor: COLORS.primaryTint,
        margin: 20,
        borderRadius: 15,
    },
    statItem: {
        alignItems: 'center',
    },
    statVal: {
        fontSize: 28,
        fontWeight: 'bold',
        color: COLORS.primary,
    },
    statLabel: {
        fontSize: 14,
        color: '#666',
        fontWeight: '500',
    },
    content: {
        flex: 1,
    },
    list: {
        paddingHorizontal: 20,
        paddingBottom: 20,
    },
    card: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        backgroundColor: '#fff',
        borderRadius: 15,
        padding: 15,
        marginBottom: 12,
        borderWidth: 1,
        borderColor: '#f0f0f0',
        elevation: 2,
    },
    cardInfo: {
        flexDirection: 'row',
        alignItems: 'center',
        flex: 1,
    },
    avatar: {
        width: 45,
        height: 45,
        borderRadius: 22.5,
        backgroundColor: COLORS.primaryTint,
        justifyContent: 'center',
        alignItems: 'center',
        marginRight: 12,
    },
    avatarText: {
        fontSize: 18,
        fontWeight: 'bold',
        color: COLORS.primary,
    },
    details: {
        justifyContent: 'center',
        flex: 1,
    },
    name: {
        fontSize: 16,
        fontWeight: 'bold',
        color: '#333',
    },
    meta: {
        fontSize: 12,
        color: '#888',
        marginTop: 2,
    },
    statusRow: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 4,
        marginTop: 4,
    },
    statusText: {
        fontSize: 11,
        fontWeight: '700',
    },
    actions: {
        flexDirection: 'row',
        gap: 10,
    },
    actionBtn: {
        width: 40,
        height: 40,
        borderRadius: 20,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#f9f9f9',
    },
});

export default AdminDashboardScreen;
