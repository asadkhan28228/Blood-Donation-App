import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Linking } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { COLORS } from '../constants/theme';

const DonorDetailScreen = ({ route, navigation }) => {
    const { donor } = route.params;

    const calculateNextDonation = (lastDate) => {
        if (!lastDate) return null;
        const date = new Date(lastDate);
        date.setDate(date.getDate() + 90);
        return date.toISOString().split('T')[0];
    };

    const nextDate = calculateNextDonation(donor.lastDonationDate || donor.createdAt);
    const today = new Date().toISOString().split('T')[0];
    const isEligible = today >= nextDate;

    const handleCall = () => {
        Linking.openURL(`tel:${donor.phone}`);
    };

    return (
        <SafeAreaView style={styles.container}>
            <View style={styles.header}>
                <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
                    <Ionicons name="arrow-back" size={24} color="#000" />
                </TouchableOpacity>
                <Text style={styles.headerTitle}>{donor.fullName}</Text>
            </View>

            <ScrollView contentContainerStyle={styles.content}>
                <View style={styles.topCard}>
                    <View style={styles.avatarRow}>
                        <View style={styles.avatar}>
                            <Ionicons name="location-sharp" size={30} color={COLORS.primary} />
                        </View>
                        <View style={styles.locationInfo}>
                            <Text style={styles.locationTitle}>{donor.city}</Text>
                            <View style={styles.statusBadgeRow}>
                                <View style={[styles.dot, { backgroundColor: isEligible ? '#4CAF50' : '#FF9800' }]} />
                                <Text style={[styles.statusTagText, { color: isEligible ? '#4CAF50' : '#FF9800' }]}>
                                    {isEligible ? 'Can Donate Now' : `Next: ${nextDate}`}
                                </Text>
                            </View>
                        </View>
                        <View style={styles.bloodTag}>
                            <Text style={styles.bloodText}>{donor.bloodGroup}</Text>
                        </View>
                    </View>

                    <TouchableOpacity style={styles.callStrip} onPress={handleCall}>
                        <Ionicons name="call" size={20} color="#2BA84A" />
                        <Text style={styles.callText}>Call: {donor.phone}</Text>
                    </TouchableOpacity>
                </View>

                <View style={styles.section}>
                    <Text style={styles.sectionHeader}>Donor Information</Text>

                    <View style={styles.infoBox}>
                        <View style={styles.infoLine}>
                            <View>
                                <Text style={styles.infoSubtitle}>Blood Group</Text>
                                <Text style={styles.infoValue}>{donor.bloodGroup}</Text>
                            </View>
                            <Ionicons name="water-outline" size={20} color={COLORS.primary} />
                        </View>

                        <View style={[styles.infoLine, { borderTopWidth: 1, borderTopColor: '#f5f5f5', marginTop: 15, paddingTop: 15 }]}>
                            <View>
                                <Text style={styles.infoSubtitle}>Age & Gender</Text>
                                <Text style={styles.infoValue}>{donor.age} Yrs • {donor.gender}</Text>
                            </View>
                            <Ionicons name="person-outline" size={20} color={COLORS.primary} />
                        </View>

                        <View style={[styles.infoLine, { borderTopWidth: 1, borderTopColor: '#f5f5f5', marginTop: 15, paddingTop: 15 }]}>
                            <View>
                                <Text style={styles.infoSubtitle}>Phone Number</Text>
                                <Text style={styles.infoValue}>{donor.phone}</Text>
                            </View>
                            <Ionicons name="call-outline" size={20} color="#2BA84A" />
                        </View>

                        <View style={[styles.infoLine, { borderTopWidth: 1, borderTopColor: '#f5f5f5', marginTop: 15, paddingTop: 15 }]}>
                            <View>
                                <Text style={styles.infoSubtitle}>Location / City</Text>
                                <Text style={styles.infoValue}>{donor.city}</Text>
                            </View>
                            <Ionicons name="location-outline" size={20} color={COLORS.primary} />
                        </View>

                        <View style={[styles.infoLine, { borderTopWidth: 1, borderTopColor: '#f5f5f5', marginTop: 15, paddingTop: 15 }]}>
                            <View>
                                <Text style={styles.infoSubtitle}>Last Donation Date</Text>
                                <Text style={styles.infoValue}>{(donor.lastDonationDate || 'Not recorded').split('T')[0]}</Text>
                            </View>
                            <Ionicons name="calendar-outline" size={20} color={COLORS.primary} />
                        </View>
                    </View>
                </View>
            </ScrollView>
        </SafeAreaView>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
    },
    header: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingHorizontal: 20,
        paddingVertical: 15,
    },
    backBtn: {
        marginRight: 15,
    },
    headerTitle: {
        fontSize: 20,
        fontWeight: 'bold',
    },
    content: {
        padding: 20,
    },
    topCard: {
        backgroundColor: '#fdfdfd',
        borderRadius: 20,
        padding: 20,
        borderWidth: 1,
        borderColor: '#f0f0f0',
        marginBottom: 25,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.05,
        shadowRadius: 10,
        elevation: 2,
    },
    avatarRow: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 20,
    },
    avatar: {
        width: 60,
        height: 60,
        borderRadius: 30,
        backgroundColor: '#FDEFF2',
        justifyContent: 'center',
        alignItems: 'center',
    },
    locationInfo: {
        flex: 1,
        marginLeft: 15,
    },
    locationTitle: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#1a1a1a',
    },
    statusBadgeRow: {
        flexDirection: 'row',
        alignItems: 'center',
        marginTop: 4,
        gap: 5,
    },
    dot: {
        width: 8,
        height: 8,
        borderRadius: 4,
    },
    statusTagText: {
        fontSize: 12,
        fontWeight: 'bold',
    },
    bloodTag: {
        backgroundColor: COLORS.primary,
        paddingHorizontal: 12,
        paddingVertical: 8,
        borderRadius: 10,
    },
    bloodText: {
        color: '#fff',
        fontWeight: 'bold',
        fontSize: 16,
    },
    callStrip: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#fff',
        borderWidth: 1,
        borderColor: '#eee',
        borderRadius: 12,
        padding: 12,
        gap: 10,
    },
    callText: {
        fontSize: 15,
        fontWeight: 'bold',
        color: '#444',
    },
    section: {
        marginTop: 10,
    },
    sectionHeader: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#1a1a1a',
        marginBottom: 15,
    },
    infoBox: {
        backgroundColor: '#fff',
        borderWidth: 1,
        borderColor: '#f0f0f0',
        borderRadius: 15,
        padding: 20,
    },
    infoLine: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
    },
    infoTitle: {
        fontSize: 15,
        fontWeight: '700',
        color: '#333',
        marginBottom: 10,
    },
    infoSubtitle: {
        fontSize: 12,
        color: '#999',
        marginBottom: 2,
    },
    infoValue: {
        fontSize: 14,
        color: '#666',
        lineHeight: 20,
        maxWidth: '90%',
    }
});

export default DonorDetailScreen;
