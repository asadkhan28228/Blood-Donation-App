import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Alert, KeyboardAvoidingView, Platform } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import axios from 'axios';
import Input from '../components/Input';
import Button from '../components/Button';
import SuccessModal from '../components/SuccessModal';
import API_URL from '../api/config';
import { COLORS } from '../constants/theme';

const AdminLoginScreen = ({ navigation }) => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [loading, setLoading] = useState(false);
    const [showSuccess, setShowSuccess] = useState(false);

    const handleLogin = async () => {
        if (!username || !password) {
            Alert.alert('Error', 'Please enter both username and password');
            return;
        }

        setLoading(true);
        try {
            const response = await axios.post(`${API_URL}/api/admin/login`, { username, password });
            if (response.data.success) {
                setShowSuccess(true);
            }
        } catch (error) {
            Alert.alert('Login Failed', error.response?.data?.message || 'Invalid credentials');
        } finally {
            setLoading(false);
        }
    };

    return (
        <SafeAreaView style={styles.container}>
            <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
                <Ionicons name="arrow-back" size={24} color="#000" />
            </TouchableOpacity>

            <KeyboardAvoidingView
                behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
                style={styles.content}
            >
                <View style={styles.header}>
                    <View style={styles.logoCircle}>
                        <Ionicons name="shield-checkmark" size={40} color={COLORS.primary} />
                    </View>
                    <Text style={styles.title}>Admin Portal</Text>
                    <Text style={styles.subtitle}>Log in to manage donors</Text>
                </View>

                <View style={styles.form}>
                    <Input
                        placeholder="Username"
                        value={username}
                        onChangeText={setUsername}
                        autoCapitalize="none"
                    />
                    <Input
                        placeholder="Password"
                        value={password}
                        onChangeText={setPassword}
                        secureTextEntry
                    />

                    <Button
                        title="Login as Admin"
                        onPress={handleLogin}
                        loading={loading}
                        style={{ marginTop: 20 }}
                    />
                </View>
            </KeyboardAvoidingView>

            <SuccessModal
                isVisible={showSuccess}
                onClose={() => {
                    setShowSuccess(false);
                    navigation.replace('AdminDashboard');
                }}
                message="Admin authentication successful. Welcome back!"
            />
        </SafeAreaView>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
    },
    backBtn: {
        padding: 20,
    },
    content: {
        flex: 1,
        justifyContent: 'center',
        paddingHorizontal: 30,
    },
    header: {
        alignItems: 'center',
        marginBottom: 40,
    },
    logoCircle: {
        width: 80,
        height: 80,
        borderRadius: 40,
        backgroundColor: COLORS.primaryTint,
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: 20,
    },
    title: {
        fontSize: 28,
        fontWeight: 'bold',
        color: '#1a1a1a',
    },
    subtitle: {
        fontSize: 16,
        color: '#888',
        marginTop: 5,
    },
    form: {
        gap: 5,
    }
});

export default AdminLoginScreen;
