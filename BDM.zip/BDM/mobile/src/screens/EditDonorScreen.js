import React, { useState } from 'react';
import { View, StyleSheet, ScrollView, Alert, Text, TouchableOpacity, KeyboardAvoidingView, Platform } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import DateTimePicker from '@react-native-community/datetimepicker';
import axios from 'axios';
import Input from '../components/Input';
import Button from '../components/Button';
import SuccessModal from '../components/SuccessModal';
import Footer from '../components/Footer';
import API_URL from '../api/config';
import { COLORS } from '../constants/theme';

const EditDonorScreen = ({ route, navigation }) => {
    const { donor } = route.params;
    const [loading, setLoading] = useState(false);
    const [showSuccess, setShowSuccess] = useState(false);
    const [showDatePicker, setShowDatePicker] = useState(false);

    const [formData, setFormData] = useState({
        fullName: donor.fullName,
        age: donor.age.toString(),
        gender: donor.gender || 'Male',
        bloodGroup: donor.bloodGroup,
        phone: donor.phone,
        city: donor.city,
        lastDonationDate: donor.lastDonationDate ? donor.lastDonationDate.split('T')[0] : '',
        medicalNotes: donor.medicalNotes || ''
    });

    const bloodGroups = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

    const handleChange = (name, value) => {
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleDateChange = (event, selectedDate) => {
        setShowDatePicker(false);
        if (selectedDate) {
            const formattedDate = selectedDate.toISOString().split('T')[0];
            handleChange('lastDonationDate', formattedDate);
        }
    };

    const handleUpdate = async () => {
        const { fullName, age, gender, bloodGroup, phone, city } = formData;

        if (!fullName.trim() || !age.trim() || !gender || !bloodGroup || !phone.trim() || !city.trim()) {
            Alert.alert('Validation Error', 'Please fill in all required fields.');
            return;
        }

        const phoneRegex = /^[0-9]{11}$/;
        if (!phoneRegex.test(phone.trim())) {
            Alert.alert('Validation Error', 'Phone number must be exactly 11 digits.');
            return;
        }

        const ageNum = parseInt(age);
        if (isNaN(ageNum) || ageNum < 18 || ageNum > 65) {
            Alert.alert('Validation Error', 'Age must be between 18 and 65.');
            return;
        }

        setLoading(true);
        try {
            await axios.put(`${API_URL}/api/donors/${donor._id}`, formData);
            setShowSuccess(true);
        } catch (error) {
            console.error(error);
            Alert.alert('Error', 'Failed to update donor info');
        } finally {
            setLoading(false);
        }
    };

    return (
        <SafeAreaView style={styles.container}>
            <View style={styles.header}>
                <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
                    <Ionicons name="arrow-back" size={24} color="#000" />
                </TouchableOpacity>
                <Text style={styles.headerTitle}>Edit Donor</Text>
            </View>

            <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
                <Input
                    label="Full Name"
                    value={formData.fullName}
                    onChangeText={(t) => handleChange('fullName', t)}
                    placeholder="Enter full name"
                />

                <Input
                    label="Age"
                    value={formData.age}
                    onChangeText={(t) => handleChange('age', t)}
                    keyboardType="numeric"
                    placeholder="Enter age (18-65)"
                />

                <Text style={styles.label}>Gender</Text>
                <View style={styles.genderRow}>
                    <TouchableOpacity
                        style={[styles.genderBtn, formData.gender === 'Male' && styles.genderBtnActive]}
                        onPress={() => handleChange('gender', 'Male')}
                    >
                        <Ionicons name="man" size={18} color={formData.gender === 'Male' ? '#fff' : '#888'} />
                        <Text style={[styles.genderBtnText, formData.gender === 'Male' && styles.genderBtnTextActive]}>Male</Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                        style={[styles.genderBtn, formData.gender === 'Female' && styles.genderBtnActive]}
                        onPress={() => handleChange('gender', 'Female')}
                    >
                        <Ionicons name="woman" size={18} color={formData.gender === 'Female' ? '#fff' : '#888'} />
                        <Text style={[styles.genderBtnText, formData.gender === 'Female' && styles.genderBtnTextActive]}>Female</Text>
                    </TouchableOpacity>
                </View>

                <Text style={styles.label}>Blood Group</Text>
                <View style={styles.bloodGrid}>
                    {bloodGroups.map((bg) => (
                        <TouchableOpacity
                            key={bg}
                            style={[styles.bloodBtn, formData.bloodGroup === bg && styles.bloodBtnActive]}
                            onPress={() => handleChange('bloodGroup', bg)}
                        >
                            <Text style={[styles.bloodBtnText, formData.bloodGroup === bg && styles.bloodBtnTextActive]}>{bg}</Text>
                        </TouchableOpacity>
                    ))}
                </View>

                <Input
                    label="Phone Number"
                    value={formData.phone}
                    onChangeText={(t) => handleChange('phone', t)}
                    keyboardType="phone-pad"
                    placeholder="11-digit phone number"
                />

                <Input
                    label="City / Location"
                    value={formData.city}
                    onChangeText={(t) => handleChange('city', t)}
                    placeholder="Enter city"
                />

                <Text style={styles.label}>Last Donation Date</Text>
                <TouchableOpacity
                    style={styles.dateSelector}
                    onPress={() => setShowDatePicker(true)}
                    activeOpacity={0.7}
                >
                    <Text style={[styles.dateText, !formData.lastDonationDate && { color: '#bbb' }]}>
                        {formData.lastDonationDate || 'Select Date'}
                    </Text>
                    <Ionicons name="calendar-outline" size={20} color={COLORS.primary} />
                </TouchableOpacity>

                {showDatePicker && (
                    <DateTimePicker
                        value={formData.lastDonationDate ? new Date(formData.lastDonationDate) : new Date()}
                        mode="date"
                        display="default"
                        onChange={handleDateChange}
                        maximumDate={new Date()}
                    />
                )}

                <Input
                    label="Medical Notes (Optional)"
                    value={formData.medicalNotes}
                    onChangeText={(t) => handleChange('medicalNotes', t)}
                    multiline
                    numberOfLines={3}
                    placeholder="Any health conditions..."
                />

                <Button
                    title="Update Donor Profile"
                    onPress={handleUpdate}
                    loading={loading}
                    style={{ marginTop: 20 }}
                />
                <Footer />
            </ScrollView>

            <SuccessModal
                isVisible={showSuccess}
                onClose={() => {
                    setShowSuccess(false);
                    navigation.goBack();
                }}
                message="Donor details have been updated successfully."
            />
        </SafeAreaView>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
    },
    header: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingHorizontal: 20,
        paddingVertical: 15,
        borderBottomWidth: 1,
        borderBottomColor: '#f5f5f5',
    },
    backBtn: {
        marginRight: 15,
    },
    headerTitle: {
        fontSize: 20,
        fontWeight: 'bold',
    },
    content: {
        padding: 20,
        paddingBottom: 50,
    },
    label: {
        fontSize: 14,
        fontWeight: '600',
        color: '#666',
        marginBottom: 10,
        marginTop: 5,
    },
    genderRow: {
        flexDirection: 'row',
        gap: 15,
        marginBottom: 20,
    },
    genderBtn: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        paddingVertical: 12,
        borderRadius: 12,
        backgroundColor: '#f8f9fa',
        borderWidth: 1,
        borderColor: '#eee',
        gap: 8,
    },
    genderBtnActive: {
        backgroundColor: COLORS.primary,
        borderColor: COLORS.primary,
    },
    genderBtnText: {
        fontSize: 14,
        fontWeight: '700',
        color: '#888',
    },
    genderBtnTextActive: {
        color: '#fff',
    },
    bloodGrid: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        gap: 10,
        marginBottom: 20,
    },
    bloodBtn: {
        paddingHorizontal: 15,
        paddingVertical: 10,
        borderRadius: 10,
        backgroundColor: '#f5f5f5',
        borderWidth: 1,
        borderColor: '#eee',
        minWidth: 60,
        alignItems: 'center',
    },
    bloodBtnActive: {
        backgroundColor: COLORS.primary,
        borderColor: COLORS.primary,
    },
    bloodBtnText: {
        fontWeight: 'bold',
        color: '#666',
    },
    bloodBtnTextActive: {
        color: '#fff',
    },
    dateSelector: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        backgroundColor: '#f8f9fa',
        borderRadius: 12,
        paddingHorizontal: 15,
        height: 55,
        borderWidth: 1,
        borderColor: '#eee',
        marginBottom: 20,
    },
    dateText: {
        fontSize: 16,
        color: '#333',
        fontWeight: '500',
    }
});

export default EditDonorScreen;
