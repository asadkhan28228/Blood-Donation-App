import React, { useState, useEffect, useCallback } from 'react';
import { View, Text, FlatList, StyleSheet, ActivityIndicator, TouchableOpacity, Linking, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useFocusEffect } from '@react-navigation/native';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import axios from 'axios';
import API_URL from '../api/config';
import Input from '../components/Input';
import { COLORS } from '../constants/theme';

const DonorListScreen = ({ navigation }) => {
    const [donors, setDonors] = useState([]);
    const [loading, setLoading] = useState(true);
    const [nameSearch, setNameSearch] = useState('');
    const [locationSearch, setLocationSearch] = useState('');
    const [filteredDonors, setFilteredDonors] = useState([]);
    const [selectedBloodGroup, setSelectedBloodGroup] = useState('All');

    const bloodGroups = ['All', 'A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

    const calculateNextDonation = (lastDate) => {
        if (!lastDate) return null;
        const fullDate = lastDate.split('T')[0];
        const date = new Date(fullDate);
        date.setDate(date.getDate() + 90);
        return date.toISOString().split('T')[0];
    };

    const fetchDonors = async () => {
        setLoading(true);
        try {
            const response = await axios.get(`${API_URL}/api/donors`);
            setDonors(response.data);
            applyFilters(response.data, nameSearch, locationSearch, selectedBloodGroup);
        } catch (error) {
            console.error('Fetch error:', error);
        } finally {
            setLoading(false);
        }
    };

    useFocusEffect(
        useCallback(() => {
            fetchDonors();
        }, [])
    );

    const applyFilters = (data, name, location, bloodGroup) => {
        let filtered = data;

        if (name) {
            const trimmedName = name.toLowerCase().trim();
            filtered = filtered.filter(d => d.fullName.toLowerCase().includes(trimmedName));
        }

        if (location) {
            const trimmedLoc = location.toLowerCase().trim();
            filtered = filtered.filter(d => d.city.toLowerCase().includes(trimmedLoc));
        }

        if (bloodGroup !== 'All') {
            filtered = filtered.filter(d => d.bloodGroup === bloodGroup);
        }

        setFilteredDonors(filtered);
    };

    const handleNameSearch = (text) => {
        setNameSearch(text);
        applyFilters(donors, text, locationSearch, selectedBloodGroup);
    };

    const handleLocationSearch = (text) => {
        setLocationSearch(text);
        applyFilters(donors, nameSearch, text, selectedBloodGroup);
    };

    const handleBloodSelect = (group) => {
        setSelectedBloodGroup(group);
        applyFilters(donors, nameSearch, locationSearch, group);
    };

    const renderItem = ({ item }) => {
        const nextDate = calculateNextDonation(item.lastDonationDate || item.createdAt);
        const today = new Date().toISOString().split('T')[0];
        const isEligible = today >= nextDate;

        return (
            <TouchableOpacity
                style={styles.card}
                activeOpacity={0.7}
                onPress={() => navigation.navigate('DonorDetail', { donor: item })}
            >
                <View style={styles.cardLeft}>
                    <View style={styles.avatar}>
                        <Ionicons name="person" size={24} color={COLORS.primary} />
                    </View>
                    <View style={styles.info}>
                        <Text style={styles.name}>{item.fullName}</Text>
                        <View style={styles.metaRow}>
                            <Ionicons name="location-sharp" size={14} color={COLORS.primary} />
                            <Text style={styles.metaText}>{item.city}</Text>
                        </View>
                        <View style={styles.eligibilityRow}>
                            <MaterialCommunityIcons
                                name={isEligible ? "check-circle" : "clock-outline"}
                                size={14}
                                color={isEligible ? "#4CAF50" : "#FF9800"}
                            />
                            <Text style={[styles.eligibilityText, { color: isEligible ? "#4CAF50" : "#FF9800" }]}>
                                {isEligible ? 'Can Donate Now' : `Next: ${nextDate}`}
                            </Text>
                        </View>
                    </View>
                </View>
                <View style={styles.cardRight}>
                    <View style={styles.bloodTag}>
                        <Text style={styles.bloodText}>{item.bloodGroup}</Text>
                    </View>
                    <Ionicons name="chevron-forward" size={20} color="#ccc" />
                </View>
            </TouchableOpacity>
        );
    };

    return (
        <SafeAreaView style={styles.container}>
            <View style={styles.header}>
                <TouchableOpacity onPress={() => navigation.goBack()}>
                    <Ionicons name="arrow-back" size={24} color="#000" />
                </TouchableOpacity>
                <Text style={styles.headerTitle}>Find Donors</Text>
                <TouchableOpacity onPress={fetchDonors}>
                    <Ionicons name="refresh" size={22} color={COLORS.primary} />
                </TouchableOpacity>
            </View>

            <View style={styles.content}>
                <View style={styles.searchSection}>
                    <View style={styles.inputWrapper}>
                        <Ionicons name="person-outline" size={18} color="#999" />
                        <Input
                            placeholder="Donor Name"
                            value={nameSearch}
                            onChangeText={handleNameSearch}
                            containerStyle={styles.searchInput}
                        />
                    </View>
                    <View style={styles.inputWrapper}>
                        <Ionicons name="location-outline" size={18} color="#999" />
                        <Input
                            placeholder="Location/City"
                            value={locationSearch}
                            onChangeText={handleLocationSearch}
                            containerStyle={styles.searchInput}
                        />
                    </View>
                </View>

                <View style={styles.filterBar}>
                    <Text style={styles.filterLabel}>Blood Group Filter:</Text>
                    <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.bloodPills}>
                        {bloodGroups.map((bg) => (
                            <TouchableOpacity
                                key={bg}
                                style={[styles.pill, selectedBloodGroup === bg && styles.pillActive]}
                                onPress={() => handleBloodSelect(bg)}
                            >
                                <Text style={[styles.pillText, selectedBloodGroup === bg && styles.pillTextActive]}>{bg}</Text>
                            </TouchableOpacity>
                        ))}
                    </ScrollView>
                </View>

                {loading && !donors.length ? (
                    <ActivityIndicator size="large" color={COLORS.primary} style={{ marginTop: 50 }} />
                ) : (
                    <FlatList
                        data={filteredDonors}
                        renderItem={renderItem}
                        keyExtractor={item => item._id}
                        contentContainerStyle={styles.list}
                        showsVerticalScrollIndicator={false}
                        ListEmptyComponent={
                            <View style={styles.emptyContainer}>
                                <Ionicons name="search-outline" size={50} color="#ddd" />
                                <Text style={styles.emptyText}>No donors match your filters.</Text>
                            </View>
                        }
                    />
                )}
            </View>
        </SafeAreaView>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
    },
    header: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingHorizontal: 20,
        paddingVertical: 15,
        borderBottomWidth: 1,
        borderBottomColor: '#f5f5f5',
    },
    headerTitle: {
        fontSize: 20,
        fontWeight: '700',
    },
    content: {
        flex: 1,
    },
    searchSection: {
        paddingHorizontal: 20,
        paddingTop: 15,
        gap: 10,
    },
    inputWrapper: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#F8F9FA',
        borderRadius: 12,
        paddingHorizontal: 15,
        height: 50,
        borderWidth: 1,
        borderColor: '#eee',
    },
    searchInput: {
        flex: 1,
        marginBottom: 0,
        backgroundColor: 'transparent',
        height: '100%',
    },
    filterBar: {
        marginTop: 15,
        marginBottom: 10,
    },
    filterLabel: {
        fontSize: 12,
        fontWeight: 'bold',
        color: '#666',
        marginLeft: 20,
        marginBottom: 8,
        textTransform: 'uppercase',
    },
    bloodPills: {
        paddingHorizontal: 20,
        gap: 8,
    },
    pill: {
        paddingHorizontal: 16,
        paddingVertical: 8,
        borderRadius: 10,
        backgroundColor: '#F5F5F5',
        justifyContent: 'center',
        alignItems: 'center',
        borderWidth: 1,
        borderColor: '#eee',
    },
    pillActive: {
        backgroundColor: COLORS.primary,
        borderColor: COLORS.primary,
    },
    pillText: {
        fontSize: 13,
        fontWeight: 'bold',
        color: '#666',
    },
    pillTextActive: {
        color: '#fff',
    },
    list: {
        paddingHorizontal: 20,
        paddingBottom: 20,
    },
    card: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        backgroundColor: '#fff',
        borderRadius: 15,
        padding: 15,
        marginBottom: 12,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.05,
        shadowRadius: 10,
        elevation: 2,
        borderWidth: 1,
        borderColor: '#f9f9f9',
    },
    cardLeft: {
        flexDirection: 'row',
        alignItems: 'center',
        flex: 1,
    },
    avatar: {
        width: 50,
        height: 50,
        borderRadius: 12,
        backgroundColor: COLORS.primaryTint,
        justifyContent: 'center',
        alignItems: 'center',
        marginRight: 15,
    },
    info: {
        flex: 1,
    },
    name: {
        fontSize: 16,
        fontWeight: '800',
        color: '#333',
        marginBottom: 2,
    },
    metaRow: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 4,
        marginTop: 2,
    },
    eligibilityRow: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 4,
        marginTop: 4,
    },
    eligibilityText: {
        fontSize: 11,
        fontWeight: '700',
    },
    metaText: {
        fontSize: 12,
        color: '#999',
        fontWeight: '600',
    },
    cardRight: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 10,
    },
    bloodTag: {
        backgroundColor: COLORS.primary,
        paddingHorizontal: 10,
        paddingVertical: 5,
        borderRadius: 8,
        minWidth: 40,
        alignItems: 'center',
    },
    bloodText: {
        color: '#fff',
        fontWeight: 'bold',
        fontSize: 13,
    },
    emptyContainer: {
        alignItems: 'center',
        marginTop: 60,
        gap: 10,
    },
    emptyText: {
        color: '#999',
        fontSize: 14,
        fontWeight: '600',
    }
});

export default DonorListScreen;
