import React from 'react';
import { TextInput, StyleSheet, View, Text } from 'react-native';
import { COLORS, SIZES, FONTS } from '../constants/theme';

const Input = ({ label, containerStyle, ...props }) => {
    return (
        <View style={[styles.container, containerStyle]}>
            {label && <Text style={styles.label}>{label}</Text>}
            <TextInput
                style={[styles.input, props.multiline && styles.multiline]}
                placeholderTextColor={COLORS.textLight}
                selectionColor={COLORS.primary}
                {...props}
            />
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        marginBottom: 18,
    },
    label: {
        fontSize: 14,
        marginBottom: 8,
        color: COLORS.text,
        fontWeight: '600',
    },
    input: {
        backgroundColor: '#fff',
        borderWidth: 1.5,
        borderColor: COLORS.border,
        borderRadius: 14,
        padding: 14,
        fontSize: 16,
        color: COLORS.text,
        shadowColor: COLORS.shadow,
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.5,
        shadowRadius: 4,
    },
    multiline: {
        minHeight: 100,
        textAlignVertical: 'top',
    },
});

export default Input;
