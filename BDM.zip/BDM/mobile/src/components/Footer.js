import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

const Footer = () => {
    return (
        <View style={styles.footer}>
            <Text style={styles.footerText}>Designed By Senan</Text>
        </View>
    );
};

const styles = StyleSheet.create({
    footer: {
        width: '100%',
        paddingVertical: 20,
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: 20,
        marginBottom: 40,
    },
    footerText: {
        fontSize: 14,
        color: '#bbb',
        fontWeight: '600',
        letterSpacing: 0.5,
    },
});

export default Footer;
