import React, { useRef } from 'react';
import { TouchableOpacity, Text, StyleSheet, ActivityIndicator, Animated } from 'react-native';
import { COLORS } from '../constants/theme';

const Button = ({ title, onPress, type = 'primary', loading = false, disabled = false, style }) => {
    const scaleAnim = useRef(new Animated.Value(1)).current;

    const handlePressIn = () => {
        Animated.spring(scaleAnim, {
            toValue: 0.96,
            useNativeDriver: true,
        }).start();
    };

    const handlePressOut = () => {
        Animated.spring(scaleAnim, {
            toValue: 1,
            friction: 3,
            tension: 40,
            useNativeDriver: true,
        }).start();
    };

    return (
        <Animated.View style={[{ transform: [{ scale: scaleAnim }] }, style]}>
            <TouchableOpacity
                style={[
                    styles.button,
                    type === 'outline' ? styles.outlineButton : styles.primaryButton,
                    (disabled || loading) && styles.disabled,
                ]}
                onPress={onPress}
                onPressIn={handlePressIn}
                onPressOut={handlePressOut}
                disabled={disabled || loading}
                activeOpacity={1}
            >
                {loading ? (
                    <ActivityIndicator color={type === 'outline' ? COLORS.primary : '#fff'} />
                ) : (
                    <Text
                        style={[
                            styles.text,
                            type === 'outline' ? styles.outlineText : styles.primaryText,
                        ]}
                    >
                        {title}
                    </Text>
                )}
            </TouchableOpacity>
        </Animated.View>
    );
};

const styles = StyleSheet.create({
    button: {
        borderRadius: 18,
        paddingVertical: 16,
        alignItems: 'center',
        justifyContent: 'center',
        marginVertical: 10,
        shadowColor: COLORS.primary,
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.2,
        shadowRadius: 8,
        elevation: 4,
        paddingHorizontal: 20,
    },
    primaryButton: {
        backgroundColor: COLORS.primary,
    },
    outlineButton: {
        backgroundColor: 'transparent',
        borderWidth: 2,
        borderColor: COLORS.primary,
        shadowOpacity: 0,
        elevation: 0,
    },
    text: {
        fontSize: 16,
        fontWeight: 'bold',
    },
    primaryText: {
        color: '#fff',
    },
    outlineText: {
        color: COLORS.primary,
    },
    disabled: {
        opacity: 0.6,
    },
});

export default Button;
