// Update this URL based on your environment
// For Android Emulator: http://10.0.2.2:5000
// For Physical Device: http://<YOUR_PC_IP>:5000
// For iOS Simulator: http://localhost:5000

 const API_URL = 'http://192.168.1.7:5000';
// const API_URL = 'http://192.168.18.192:5000';

export default API_URL;
