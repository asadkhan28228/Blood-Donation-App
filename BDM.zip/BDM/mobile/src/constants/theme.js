export const COLORS = {
    primary: '#E63946',
    primaryDark: '#D62839',
    primaryTint: '#FFF1F1',
    success: '#2BA84A',
    text: '#444444',
    textLight: '#777777',
    border: '#E5E5E5',
    background: '#FFFFFF',
    white: '#FFFFFF',
    shadow: 'rgba(0, 0, 0, 0.08)',
};

export const SIZES = {
    radius: 18,
    padding: 20,
    font: 16,
};

export const FONTS = {
    h1: { fontSize: 28, fontWeight: '700' },
    h2: { fontSize: 22, fontWeight: '700' },
    h3: { fontSize: 18, fontWeight: '600' },
    body: { fontSize: 16, fontWeight: '400' },
    caption: { fontSize: 14, fontWeight: '500' },
};
