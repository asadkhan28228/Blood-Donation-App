const mongoose = require('mongoose');

const donorSchema = new mongoose.Schema({
    fullName: {
        type: String,
        required: true
    },
    age: {
        type: Number,
        required: true
    },
    gender: {
        type: String,
        required: true,
        enum: ['Male', 'Female', 'Other']
    },
    bloodGroup: {
        type: String,
        required: true,
        enum: ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-']
    },
    phone: {
        type: String,
        required: true
    },
    city: {
        type: String,
        required: true
    },
    lastDonationDate: {
        type: Date
    },
    medicalNotes: {
        type: String
    }
}, { timestamps: true });

module.exports = mongoose.model('Donor', donorSchema);
