const express = require('express');
const router = express.Router();
const Donor = require('../models/Donor');

// Create a new donor
router.post('/', async (req, res) => {
    try {
        const newDonor = new Donor(req.body);
        const savedDonor = await newDonor.save();
        res.status(201).json(savedDonor);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// Get all donors (with search & filter)
router.get('/', async (req, res) => {
    try {
        const { bloodGroup, city, name } = req.query;
        let query = {};

        if (bloodGroup) query.bloodGroup = bloodGroup;
        if (city) query.city = { $regex: city, $options: 'i' }; // Case-insensitive
        if (name) query.fullName = { $regex: name, $options: 'i' };

        const donors = await Donor.find(query).sort({ createdAt: -1 });
        res.json(donors);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// Get single donor by ID
router.get('/:id', async (req, res) => {
    try {
        const donor = await Donor.findById(req.params.id);
        if (!donor) return res.status(404).json({ message: 'Donor not found' });
        res.json(donor);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// Update a donor
router.put('/:id', async (req, res) => {
    try {
        const updatedDonor = await Donor.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!updatedDonor) return res.status(404).json({ message: 'Donor not found' });
        res.json(updatedDonor);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// Delete a donor
router.delete('/:id', async (req, res) => {
    try {
        const deletedDonor = await Donor.findByIdAndDelete(req.params.id);
        if (!deletedDonor) return res.status(404).json({ message: 'Donor not found' });
        res.json({ message: 'Donor deleted successfully' });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

module.exports = router;
