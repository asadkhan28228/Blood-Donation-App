const express = require('express');
const router = express.Router();

// Hardcoded admin for simplicity, as per medical app prototype
const ADMIN_CREDENTIALS = {
    username: 'admin',
    password: 'password123'
};

router.post('/login', (req, res) => {
    const { username, password } = req.body;
    console.log('Admin Login Attempt:', { username, password });

    if (username?.toLowerCase() === ADMIN_CREDENTIALS.username && password === ADMIN_CREDENTIALS.password) {
        console.log('Login Success');
        res.json({
            success: true,
            message: 'Logged in successfully',
            admin: { username: 'Admin User' }
        });
    } else {
        console.log('Login Failed: Invalid credentials');
        res.status(401).json({
            success: false,
            message: 'Invalid username or password'
        });
    }
});

module.exports = router;
