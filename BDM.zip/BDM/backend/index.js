require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(express.json());
app.use(cors());

// Database Connection
mongoose.connect(process.env.MONGODB_URI)
    .then(() => console.log('MongoDB Connected'))
    .catch(err => console.log(err));

// Simple Route
app.get('/', (req, res) => {
    res.send('API is running...');
});

// Import Routes (will add later)
const donorRoutes = require('./routes/donors');
const adminRoutes = require('./routes/admin');
app.use('/api/donors', donorRoutes);
app.use('/api/admin', adminRoutes);

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
